clear all;
clc;

% Creazione di una suddivisione dell'intervallo e quindi 
% x: vettore di 2000 nodi equispaziati in [-1e-10,1e-10]
yexact = 1;   %soluzione esatta
x = linspace(-1e-10,1e-10,2000);

% Calcolo y in funzione del vettore x
y = ((1+x)-1)./x;

% Calcolo l'errore relativo
errRel = abs(y-yexact)/abs(yexact);

% Grafico 1
figure(1);
plot(x,y);
title('Valore di f(x)');
xlabel('x');

% Grafico 2
figure(2);
semilogy(x,errRel);
title('Errore relativo');
xlabel('x');