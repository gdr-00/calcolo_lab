clear all;
clc;

p=4.999999999995*10^4; 
q=10^(-2);
sol=10^(-7);

% ALGORITMO 1
s=sqrt(p^2+q);
alg1=-p+s;  % Risultato del primo algoritmo

% ALGORITMO 2
s=sqrt(p^2+q);
v=p+s;
alg2=q/v;   % Risultato del secondo algoritmo

% Soluzione fornita dal primo algoritmo.
fprintf('\n \t [ALG.1]: %10.19f',alg1); 

% Soluzione fornita dal secondo algoritmo.
fprintf('\n \t [ALG.2]: %10.19f',alg2); 

% Errore relativo del primo algoritmo.
rerr1 =abs(alg1-sol)/abs(sol); 
% Errore relativo del secondo algoritmo.
rerr2=abs(alg2-sol)/abs(sol); 
% Stampa risultati.
fprintf('\n \t [REL.ERR.ALG.1]: %2.2e',rerr1);
fprintf('\n \t [REL.ERR.ALG.2]: %2.2e',rerr2);

fprintf('\n \n');