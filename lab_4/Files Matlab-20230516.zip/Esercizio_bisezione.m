clear all;
close all;
clc;

% Definisco gli estremi dell'intervallo
a = 0; b = 1;
% Definisco la funzione f
f = @(x) exp(x) - 2 + x;

x = linspace(a,b,100);
% Plot della funzione f in [0,1]
figure(1)
plot(x,f(x),'b')

% Valore del segno del prodotto del valore della funzione f agli estremi
% dell'intervallo
fprintf('\n \t Il valore di sign(f(a)f(b)) = %d \n',sign(f(a)*f(b)))

% Utilizzo del metodo di bisezione
tol = 1e-8; max_iter = 500;
[x,x_all,iter] = bisezione(f,a,b,tol,max_iter);

% Calcolo Errori relativi
sol = 0.4428544010023885;
err_rel = abs(x_all-sol)/sol;

% Plot in semilogy dell'errore
figure(2)
semilogy(1:iter, err_rel,'ro-')



% Esercizio per casa
[x2,x_all2,iter2] = bisezione2(f,a,b,tol,max_iter);
err_rel2 = abs(x_all2-sol)/sol;

hold on;
semilogy(1:iter2, err_rel2,'b--')